const que_ans = [ {"que": "what time shall we go shopping? Let’s see how the weather looks and ---- it ----   ---- .",
                   "ans": [ "play it by ear"],
                   "half_ans" : " ---- it ---- ----",
                   "buttons": [ "game","with","by", "nose", "ear" ,"hear","show" ,"play"]
                    ,
                    "index" : 14
                },
                {"que": "in fact he’s not right for this role, he has his ---- in ---- ----.",
                 "ans": "head in the cloud",
                 "half_ans" : "---- in ---- ----",
                 "buttons": ["face" ,"the" ,"mind" , "sky"  ,"top","head" , "star" ,"cloud"],
                 "index" : 12
            },
            {"que": "what time shall we go shopping? Let’s see how the weather looks and ---- it ---- ---- .",
            "ans": [ "play it by ear"],
            "half_ans" : " ---- it ---- ----",
            "buttons": [ "game","with","by", "nose", "ear" ,"hear","show" ,"play"]
             ,
             "index" : 14
         },
                {"que": "teacher’s colourful waistcoats and unusual taste for hats made him a ---- -than- ---- character in the local community.",
                 "ans": "larger than life",
                 "half_ans" : " ---- -than- ----  ",
                 "buttons": ["face" ,"the" ,"mind" , "sky"  ,"top","head" , "star" ,"cloud"]
            },
                {"que": "What time shall we go shopping? Let’s see how the weather looks and .... it .... .... .",
                "ans": [ "play it by ear"],
                "half_ans" : " .... it .... .... .",
                "buttons": [ "game","with","by", "nose",
                    "ear" ,"hear","show" ,"play"]
             },
             {"que": "In fact he’s not right for this role, he has his .... in .... .... .",
             "ans": "head in the cloud",
             "half_ans" : " .... in .... .... ",
             "buttons": ["face" ,"the" ,"mind" , "sky"  ,"top","head" , "star" ,"cloud"]
        }
]