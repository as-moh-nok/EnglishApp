# EnglishApp
An App for learning English phrases with persian phrases
